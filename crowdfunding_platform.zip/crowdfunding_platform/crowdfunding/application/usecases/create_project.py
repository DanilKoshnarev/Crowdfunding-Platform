from crowdfunding.domain.services.project_service import ProjectService

class CreateProjectUseCase:
    def __init__(self, project_service):
        self.project_service = project_service

    def execute(self, title, description, goal_amount, creator):
        self.project_service.create_project(title, description, goal_amount, creator)