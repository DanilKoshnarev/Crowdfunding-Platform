class Project:
    def __init__(self, title, description, goal_amount, creator):
        self.title = title
        self.description = description
        self.goal_amount = goal_amount
        self.creator = creator