class ProjectRepository:
    def save(self, project):
        raise NotImplementedError