class ProjectService:
    def __init__(self, repository):
        self.repository = repository

    def create_project(self, title, description, goal_amount, creator):
        project = Project(title, description, goal_amount, creator)
        self.repository.save(project)