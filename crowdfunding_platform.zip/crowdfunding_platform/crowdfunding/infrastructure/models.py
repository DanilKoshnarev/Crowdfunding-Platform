from django.db import models

class ProjectModel(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    goal_amount = models.DecimalField(max_digits=10, decimal_places=2)
    creator = models.CharField(max_length=100)