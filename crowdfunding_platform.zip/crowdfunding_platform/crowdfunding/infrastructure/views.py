from django.shortcuts import render
from django.views import View

class ProjectListView(View):
    def get(self, request):
        return render(request, 'crowdfunding/project_list.html')